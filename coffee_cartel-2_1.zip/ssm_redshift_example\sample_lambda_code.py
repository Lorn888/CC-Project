from connect_to_db import *
import os

# Name of the environment variable which has the SSM parameter name as its value.
# The SSM parameter name will be "<team name>_redshift_settings".
ssm_env_var_name = 'SSM_PARAMETER_NAME'

def lambda_handler(event, context):
    print('lambda_handler: starting')

    try:

        ssm_param_name = os.environ[ssm_env_var_name] or 'NOT_SET'
        print(f'lambda_handler: ssm_param_name={ssm_param_name} from ssm_env_var_name={ssm_env_var_name}')

        # connection
        redshift_details = get_ssm_param(ssm_param_name)
        conn, cur = open_sql_database_connection_and_cursor(redshift_details)


        print(f'lambda_handler: done')

    except Exception as whoopsy:
        # ...exception reporting
        print(f'lambda_handler: failure, error=${whoopsy}')
        raise whoopsy
